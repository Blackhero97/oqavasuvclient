/**
 * BM CRM - Admin PC Server (Minimal)
 * Hikvision webhook qabul qiladi va MongoDB ga saqlaydi
 */

import 'dotenv/config';
import express from 'express';
import mongoose from 'mongoose';
import multer from 'multer';
import cors from 'cors';

const app = express();
const PORT = process.env.PORT || 5000;
const upload = multer();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB
mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('✅ MongoDB Atlas ulanildi'))
    .catch(err => console.error('❌ MongoDB xato:', err.message));

// Employee Schema
const Employee = mongoose.model('Employee', new mongoose.Schema({
    employeeId: Number,
    hikvisionEmployeeId: String,
    name: String,
    role: { type: String, default: 'staff' },
    department: { type: String, default: 'IT' },
    status: { type: String, default: 'active' }
}, { strict: false }));

// Attendance Schema (oddiy - events yo'q)
const Attendance = mongoose.model('Attendance', new mongoose.Schema({
    employeeId: Number,
    hikvisionEmployeeId: String,
    name: String,
    role: String,
    department: String,
    date: String,
    firstCheckIn: String,
    lastCheckOut: String,
    status: { type: String, default: 'present' }
}, { strict: false }));

// Webhook handler
const webhookHandler = async (req, res) => {
    try {
        console.log('\n📨 Webhook qabul qilindi');

        let eventData = req.body;
        if (req.body.event_log) {
            try { eventData = JSON.parse(req.body.event_log); } catch(e) {}
        }

        const acEvent = eventData.AccessControllerEvent || {};
        const employeeNo = acEvent.employeeNoString || eventData.employeeNoString;
        const employeeName = acEvent.name || 'Unknown';

        if (!employeeNo) {
            console.log('ℹ️  Face recognition kutilmoqda...');
            return res.json({ success: true, message: 'No employee data' });
        }

        console.log(`👤 ${employeeName} (ID: ${employeeNo})`);

        const eventTime = new Date(eventData.dateTime || new Date());
        const dateStr = eventTime.toISOString().split('T')[0];
        const timeStr = eventTime.toLocaleTimeString('en-GB', {
            timeZone: 'Asia/Tashkent',
            hour: '2-digit',
            minute: '2-digit',
            hour12: false
        });

        // Employee
        let employee = await Employee.findOne({ hikvisionEmployeeId: employeeNo });
        if (!employee) {
            employee = new Employee({
                employeeId: parseInt(employeeNo) || Date.now(),
                hikvisionEmployeeId: employeeNo,
                name: employeeName,
                role: 'staff',
                status: 'active'
            });
            await employee.save();
            console.log(`✅ Yangi xodim: ${employeeName}`);
        }

        // Attendance
        let attendance = await Attendance.findOne({
            hikvisionEmployeeId: employeeNo,
            date: dateStr
        });

        if (!attendance) {
            attendance = new Attendance({
                employeeId: employee.employeeId,
                hikvisionEmployeeId: employeeNo,
                name: employeeName,
                role: employee.role,
                department: employee.department,
                date: dateStr,
                firstCheckIn: timeStr,
                lastCheckOut: null,
                status: 'present'
            });
            console.log(`✅ ${employeeName} - KELDI ${timeStr}`);
        } else {
            // Ketish vaqtini yangilash
            attendance.lastCheckOut = timeStr;
            console.log(`✅ ${employeeName} - KETDI ${timeStr}`);
        }

        await attendance.save();
        console.log('💾 MongoDB ga saqlandi');

        res.json({ success: true, name: employeeName, time: timeStr });
    } catch (error) {
        console.error('❌ Xato:', error.message);
        res.status(500).json({ error: error.message });
    }
};

// Routes
app.post('/webhook', upload.any(), webhookHandler);
app.post('/webhook/hikvision', upload.any(), webhookHandler);
app.get('/health', (req, res) => res.json({ status: 'OK' }));

// Start
app.listen(PORT, '0.0.0.0', () => {
    console.log('\n🌉 BM CRM ADMIN SERVER');
    console.log('='.repeat(40));
    console.log(`📡 http://0.0.0.0:${PORT}`);
    console.log(`🎯 Webhook: /webhook/hikvision`);
    console.log('='.repeat(40));
    console.log('⏳ Terminal kutilmoqda...\n');
});
